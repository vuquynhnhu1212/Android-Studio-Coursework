package com.example.yogaadmin.schedule;

import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.DatabaseHelper;
import com.example.yogaadmin.R;
import com.example.yogaadmin.course.YogaCourse;

import java.util.Calendar;

public class CreateSchedule extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private DatePicker datePicker;
    private long courseId; // Will be passed from intent

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_yoga_schedule);

        // Get course ID from intent
        courseId = getIntent().getLongExtra("COURSE_ID", -1);
        if (courseId == -1) {
            Toast.makeText(this, "No course selected", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        dbHelper = new DatabaseHelper(this);
        datePicker = findViewById(R.id.dpSchedule);

        // Set current date and restrict to course's day of week
        Calendar calendar = Calendar.getInstance();
        setToNextDayOfWeek(calendar, courseId);
        datePicker.init(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH), null);
    }

    private void setToNextDayOfWeek(Calendar calendar, long courseId) {
        YogaCourse course = dbHelper.getCourse(courseId);
        if (course != null) {
            int targetDay = convertDayOfWeekToCalendar(course.getDayOfWeek());
            int currentDay = calendar.get(Calendar.DAY_OF_WEEK);

            // Calculate days to add to get to the next occurrence of target day
            int daysToAdd = (targetDay - currentDay + 7) % 7;
            if (daysToAdd == 0) daysToAdd = 7; // If today is the day, go to next week

            calendar.add(Calendar.DAY_OF_YEAR, daysToAdd);
        }
    }

    private int convertDayOfWeekToCalendar(String dayOfWeek) {
        switch (dayOfWeek.toLowerCase()) {
            case "monday": return Calendar.MONDAY;
            case "tuesday": return Calendar.TUESDAY;
            case "wednesday": return Calendar.WEDNESDAY;
            case "thursday": return Calendar.THURSDAY;
            case "friday": return Calendar.FRIDAY;
            case "saturday": return Calendar.SATURDAY;
            case "sunday": return Calendar.SUNDAY;
            default: return Calendar.MONDAY;
        }
    }

    public void onClickAddSchedule(View v) {
        try {
            EditText etTeacher = findViewById(R.id.etTeacher);
            EditText etComment = findViewById(R.id.edmComment);

            String teacher = etTeacher.getText().toString().trim();
            String comment = etComment.getText().toString().trim();

            if (teacher.isEmpty()) {
                Toast.makeText(this, "Please enter teacher name", Toast.LENGTH_SHORT).show();
                return;
            }

            // Get selected date
            String date = String.format("%02d/%02d/%04d",
                    datePicker.getDayOfMonth(),
                    datePicker.getMonth() + 1,
                    datePicker.getYear());

            // Create new schedule
            YogaSchedule schedule = new YogaSchedule(
                    0, // ID auto-generated
                    courseId,
                    date,
                    teacher,
                    comment.isEmpty() ? null : comment
            );

            long scheduleId = dbHelper.createSchedule(schedule);

            if (scheduleId != -1) {
                Toast.makeText(this, "Schedule created!", Toast.LENGTH_LONG).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to create schedule", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void onClickClearSchedule(View v) {
        clearForm();
    }

    private void clearForm() {
        ((EditText) findViewById(R.id.etTeacher)).setText("");
        ((EditText) findViewById(R.id.edmComment)).setText("");

        // Reset to next valid date
        Calendar calendar = Calendar.getInstance();
        setToNextDayOfWeek(calendar, courseId);
        datePicker.updateDate(calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}