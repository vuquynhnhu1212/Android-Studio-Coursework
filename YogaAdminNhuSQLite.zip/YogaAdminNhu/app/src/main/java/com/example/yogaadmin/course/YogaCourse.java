package com.example.yogaadmin.course;

public class YogaCourse {
    private long id;
    private String dayOfWeek;  // Monday, Tuesday, etc.
    private String time;       // 10:00, 11:00, etc.
    private int capacity;      // Maximum attendees
    private int duration;      // In minutes
    private double price;      // Price per class
    private String type;       // Flow Yoga, Aerial Yoga, etc.
    private String description; // Optional description

    // Constructors
    public YogaCourse() {}
    public YogaCourse(long id, String dayOfWeek, String time, int capacity, int duration,
                      double price, String type, String description) {
        this.id = id;
        this.dayOfWeek = dayOfWeek;
        this.time = time;
        this.capacity = capacity;
        this.duration = duration;
        this.price = price;
        this.type = type;
        this.description = description;
    }

    // Getters and Setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Helper method to display course information
    @Override
    public String toString() {
        return dayOfWeek + " at " + time + " - " + type + " (" + duration + " mins, £" + price + ")";
    }
}