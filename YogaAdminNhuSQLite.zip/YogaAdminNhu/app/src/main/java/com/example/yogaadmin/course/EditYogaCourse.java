package com.example.yogaadmin.course;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.DatabaseHelper;
import com.example.yogaadmin.R;

public class EditYogaCourse extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private YogaCourse currentCourse;
    private Spinner spDayEdit, spTimeEdit, spTypeEdit, spDurationEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_yoga_course);

        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Initialize spinners with correct IDs from XML
        spDayEdit = findViewById(R.id.spDayOfWeekEdit);
        spTimeEdit = findViewById(R.id.spTimeEdit);
        spTypeEdit = findViewById(R.id.spinner2); // Note: This matches your XML id
        spDurationEdit = findViewById(R.id.spDurationEdit);

        // Get the course ID from intent
        long courseId = getIntent().getLongExtra("COURSE_ID", -1);
        if (courseId == -1) {
            Toast.makeText(this, "Error: Course not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Get the course from database
        currentCourse = dbHelper.getCourse(courseId);
        if (currentCourse == null) {
            Toast.makeText(this, "Error: Course not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Populate the form with existing course data
        populateForm(currentCourse);
    }

    private void populateForm(YogaCourse course) {
        // Set spinner selections (no need to set adapters since they're defined in XML)
        setSpinnerSelection(spDayEdit, course.getDayOfWeek());
        setSpinnerSelection(spTimeEdit, course.getTime());
        setSpinnerSelection(spTypeEdit, course.getType());
        setSpinnerSelection(spDurationEdit, course.getDuration() + " minutes");

        // Set other fields
        ((EditText) findViewById(R.id.edPriceEdit)).setText(String.valueOf(course.getPrice()));
        ((EditText) findViewById(R.id.edCapacityEdit)).setText(String.valueOf(course.getCapacity()));
        ((EditText) findViewById(R.id.edmDesEdit)).setText(course.getDescription());
    }

    private void setSpinnerSelection(Spinner spinner, String value) {
        if (value != null && spinner != null) {
            for (int i = 0; i < spinner.getCount(); i++) {
                if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(value)) {
                    spinner.setSelection(i);
                    break;
                }
            }
        }
    }

    public void onClickEditYogaCourse(View v) {
        // Get references to all input fields
        EditText edPrice = findViewById(R.id.edPriceEdit);
        EditText edCapacity = findViewById(R.id.edCapacityEdit);
        EditText edDescription = findViewById(R.id.edmDesEdit);

        try {
            // Get all updated values from the form
            String dayOfWeek = spDayEdit.getSelectedItem().toString();
            String time = spTimeEdit.getSelectedItem().toString();
            String type = spTypeEdit.getSelectedItem().toString();
            String durationStr = spDurationEdit.getSelectedItem().toString();
            String description = edDescription.getText().toString();

            // Parse numerical values
            int duration = Integer.parseInt(durationStr.replaceAll("[^0-9]", ""));
            int capacity = Integer.parseInt(edCapacity.getText().toString());
            double price = Double.parseDouble(edPrice.getText().toString());

            // Create updated YogaCourse object
            YogaCourse updatedCourse = new YogaCourse(
                    currentCourse.getId(), // Same ID as original
                    dayOfWeek,
                    time,
                    capacity,
                    duration,
                    price,
                    type,
                    description
            );

            // Update in database
            int rowsAffected = dbHelper.updateCourse(updatedCourse);

            if (rowsAffected > 0) {
                Toast.makeText(this, "Course updated successfully", Toast.LENGTH_SHORT).show();
                finish(); // Close the activity and return to previous screen
            } else {
                Toast.makeText(this, "Failed to update course", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numbers for capacity and price", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void onClickClearYogaCourse(View v) {
        // Reset form to original values
        populateForm(currentCourse);
        Toast.makeText(this, "Changes discarded", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}