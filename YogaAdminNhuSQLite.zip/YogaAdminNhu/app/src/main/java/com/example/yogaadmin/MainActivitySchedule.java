package com.example.yogaadmin;

import static com.example.yogaadmin.MainActivity.helper;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ResourceCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.schedule.CreateSchedule;
import com.example.yogaadmin.schedule.EditSchedule;

public class MainActivitySchedule extends AppCompatActivity {
    private EditText etSearchSchedule;
    private Button btnSearchSchedule;
    private YogaScheduleCursorAdapter adapter;
    private long selectedCourseId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_schedule);

        // Get the selected course ID from intent
        selectedCourseId = getIntent().getLongExtra("SELECTED_COURSE_ID", -1);

        etSearchSchedule = findViewById(R.id.etSearchSchedule);
        btnSearchSchedule = findViewById(R.id.btnSearchSchedule);

        // Initialize adapter
        adapter = new YogaScheduleCursorAdapter(
                this,
                R.layout.yoga_schedule_item,
                null,
                0
        );

        ListView lv = findViewById(R.id.lvSchedule);
        lv.setAdapter(adapter);

        // Load schedules for the selected course
        refreshScheduleList();

        btnSearchSchedule.setOnClickListener(v -> {
            String searchText = etSearchSchedule.getText().toString().trim();
            Cursor cursor;

            if (!searchText.isEmpty()) {
                // Search across multiple schedule fields
                cursor = helper.searchSchedules(searchText, selectedCourseId);
            } else {
                cursor = helper.searchSchedulesForCourse(selectedCourseId, null);
            }

            adapter.changeCursor(cursor);
        });
    }

    public void onCreateYogaSchedule(View v) {
        if (selectedCourseId == -1) {
            Toast.makeText(this, "No course selected", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create new schedule for the selected course
        Intent intent = new Intent(this, CreateSchedule.class);
        intent.putExtra("COURSE_ID", selectedCourseId);
        startActivity(intent);
    }

    public void onReturn(View v) {
        finish();
    }

    @Override
    protected void onStart() {
        super.onStart();
        refreshScheduleList();
    }

    private void refreshScheduleList() {
        Cursor cursor;
        if (selectedCourseId != -1) {
            // Show only schedules for the selected course
            cursor = helper.searchSchedulesForCourse(selectedCourseId, null);
        } else {
            // Fallback - show all schedules (shouldn't normally happen)
            cursor = helper.getAllSchedulesCursor();
        }
        adapter.changeCursor(cursor);
    }

    public class YogaScheduleCursorAdapter extends ResourceCursorAdapter {
        public YogaScheduleCursorAdapter(Context context, int layout, Cursor cursor, int flags) {
            super(context, layout, cursor, flags);
        }

        @SuppressLint("Range")
        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            TextView tvDate = view.findViewById(R.id.tvDate);
            TextView tvTeacher = view.findViewById(R.id.tvTeacher);
            TextView tvComments = view.findViewById(R.id.tvComments);
            TextView tvCourseInfo = view.findViewById(R.id.tvCourseId);
            Button btnDelete = view.findViewById(R.id.btnDeleteSchedule);
            Button btnEdit = view.findViewById(R.id.btnEditSchedule);

            long scheduleId = cursor.getLong(cursor.getColumnIndex("_id"));
            String date = cursor.getString(cursor.getColumnIndex("date"));
            String teacher = cursor.getString(cursor.getColumnIndex("teacher"));
            String comments = cursor.getString(cursor.getColumnIndex("comments"));
            String courseType = cursor.getString(cursor.getColumnIndex("type"));
            String courseTime = cursor.getString(cursor.getColumnIndex("time"));

            tvDate.setText(date);
            tvTeacher.setText(teacher);
            tvComments.setText(comments);
            tvCourseInfo.setText(courseType + " at " + courseTime);

            btnDelete.setOnClickListener(v -> confirmDeleteSchedule(context, scheduleId));
            btnEdit.setOnClickListener(v -> openEditSchedule(context, scheduleId));
        }

        private void confirmDeleteSchedule(Context context, long scheduleId) {
            new AlertDialog.Builder(context)
                    .setTitle("Delete Schedule")
                    .setMessage("Are you sure you want to delete this schedule?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        if (helper.deleteSchedule(scheduleId)) {
                            Toast.makeText(context, "Schedule deleted", Toast.LENGTH_SHORT).show();
                            refreshScheduleList();
                        } else {
                            Toast.makeText(context, "Failed to delete schedule", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }

        private void openEditSchedule(Context context, long scheduleId) {
            Intent intent = new Intent(context, EditSchedule.class);
            intent.putExtra("SCHEDULE_ID", scheduleId);
            context.startActivity(intent);
        }
    }
}