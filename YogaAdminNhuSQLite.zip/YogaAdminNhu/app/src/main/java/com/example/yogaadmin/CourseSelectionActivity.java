package com.example.yogaadmin;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.course.YogaCourse;

public class CourseSelectionActivity extends AppCompatActivity {
    private static final String TAG = "CourseSelection";
    private DatabaseHelper dbHelper;
    private CourseCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_select);

        dbHelper = new DatabaseHelper(this);
        ListView lvCourses = findViewById(R.id.lvCourseSelection);

        // Initialize with empty cursor
        adapter = new CourseCursorAdapter(this, null);
        lvCourses.setAdapter(adapter);

        // Load initial data
        loadCourseData("");

        // Set item click listener - now directly opens schedule
        lvCourses.setOnItemClickListener((parent, view, position, id) -> {
            // Highlight selection
            for (int i = 0; i < parent.getChildCount(); i++) {
                parent.getChildAt(i).setBackgroundColor(
                        getResources().getColor(android.R.color.transparent));
            }
            view.setBackgroundColor(
                    getResources().getColor(android.R.color.holo_blue_light));

            // Directly open schedule with selected course ID
            Intent intent = new Intent(CourseSelectionActivity.this, MainActivitySchedule.class);
            intent.putExtra("SELECTED_COURSE_ID", id);
            startActivity(intent);
        });

        // Search button remains
        findViewById(R.id.btnSearchCourse).setOnClickListener(v -> {
            String searchText = ((EditText) findViewById(R.id.etSearchCourse)).getText().toString().trim();
            loadCourseData(searchText);
        });

        // Remove the view schedule button from layout (activity_main_select.xml)
    }

    public void onBackButtonClicked(View view) {
        finish();
    }

    private void loadCourseData(String searchText) {
        Cursor newCursor = searchText.isEmpty() ?
                dbHelper.getAllCoursesCursor() :
                dbHelper.searchCourses(searchText);

        if (adapter != null && adapter.getCursor() != null) {
            adapter.getCursor().close();
        }

        adapter.changeCursor(newCursor);
        Log.d(TAG, "Loaded " + newCursor.getCount() + " courses");
    }

    private YogaCourse cursorToYogaCourse(Cursor cursor) {
        return new YogaCourse(
                cursor.getLong(cursor.getColumnIndexOrThrow("_id")),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_DAY)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_TIME)),
                cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_CAPACITY)),
                cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_DURATION)),
                cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_PRICE)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_TYPE)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.KEY_DESCRIPTION))
        );
    }

    @Override
    protected void onDestroy() {
        // Close cursor when activity is destroyed
        if (adapter != null && adapter.getCursor() != null) {
            adapter.getCursor().close();
        }
        if (dbHelper != null) {
            dbHelper.close();
        }
        super.onDestroy();
    }

    class CourseCursorAdapter extends CursorAdapter {
        private final LayoutInflater inflater;

        CourseCursorAdapter(Context context, Cursor cursor) {
            super(context, cursor, 0);
            this.inflater = LayoutInflater.from(context);
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            return inflater.inflate(R.layout.course_list_item, parent, false);
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            YogaCourse course = cursorToYogaCourse(cursor);

            TextView tvType = view.findViewById(R.id.tvType);
            TextView tvTime = view.findViewById(R.id.tvTime);
            TextView tvDay = view.findViewById(R.id.tvDayOfWeek);
            TextView tvDuration = view.findViewById(R.id.tvDuration);
            TextView tvCapacity = view.findViewById(R.id.tvCapacity);
            TextView tvDescription = view.findViewById(R.id.tvDescription);
            TextView tvPrice = view.findViewById(R.id.tvPrice);

            tvType.setText(course.getType());
            tvTime.setText(course.getTime());
            tvDay.setText(course.getDayOfWeek());
            tvDuration.setText(course.getDuration() + " mins");
            tvCapacity.setText(String.valueOf(course.getCapacity()));
            tvDescription.setText(course.getDescription());
            tvPrice.setText(String.format("£%.2f", course.getPrice()));
        }
    }
}