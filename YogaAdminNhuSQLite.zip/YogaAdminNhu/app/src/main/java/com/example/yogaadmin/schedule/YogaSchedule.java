package com.example.yogaadmin.schedule;

public class YogaSchedule {
    private long id;
    private long courseId;
    private String date;
    private String teacher;
    private String comments;

    public YogaSchedule() {}

    public YogaSchedule(long id, long courseId, String date, String teacher, String comments) {
        this.id = id;
        this.courseId = courseId;
        this.date = date;
        this.teacher = teacher;
        this.comments = comments;
    }

    // Getters and setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getCourseId() { return courseId; }
    public void setCourseId(long courseId) { this.courseId = courseId; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getTeacher() { return teacher; }
    public void setTeacher(String teacher) { this.teacher = teacher; }

    public String getComments() { return comments; }
    public void setComments(String comments) {
        this.comments = (comments == null || comments.trim().isEmpty()) ? null : comments.trim();
    }

    @Override
    public String toString() {
        return "Scheduled on " + date + " with " + teacher +
                (comments != null ? " (" + comments + ")" : "");
    }
}