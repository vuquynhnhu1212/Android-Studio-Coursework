package com.example.yogaadmin;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.yogaadmin.course.YogaCourse;
import com.example.yogaadmin.schedule.YogaSchedule;

public class DatabaseHelper extends SQLiteOpenHelper {
    // Database Info
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "YogaStudioDB";

    // Table names
    private static final String TABLE_COURSES = "courses";
    private static final String TABLE_SCHEDULES = "schedules";

    // Common column
    public static final String KEY_ID = "id";

    // Courses Table columns
    public static final String KEY_DAY = "day";
    public static final String KEY_TIME = "time";
    public static final String KEY_TYPE = "type";
    public static final String KEY_CAPACITY = "capacity";
    public static final String KEY_DURATION = "duration";
    public static final String KEY_PRICE = "price";
    public static final String KEY_DESCRIPTION = "description";

    // Schedules Table columns
    private static final String KEY_COURSE_ID = "course_id";
    private static final String KEY_DATE = "date";
    private static final String KEY_TEACHER = "teacher";
    private static final String KEY_COMMENTS = "comments";

    // Create tables SQL
    private static final String CREATE_TABLE_COURSES = "CREATE TABLE " + TABLE_COURSES +
            "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            KEY_DAY + " TEXT NOT NULL," +
            KEY_TIME + " TEXT NOT NULL," +
            KEY_CAPACITY + " INTEGER NOT NULL," +
            KEY_DURATION + " INTEGER NOT NULL," +
            KEY_PRICE + " REAL NOT NULL," +
            KEY_TYPE + " TEXT NOT NULL," +
            KEY_DESCRIPTION + " TEXT)";

    private static final String CREATE_TABLE_SCHEDULES = "CREATE TABLE " + TABLE_SCHEDULES +
            "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            KEY_COURSE_ID + " INTEGER NOT NULL," +
            KEY_DATE + " TEXT NOT NULL," +
            KEY_TEACHER + " TEXT NOT NULL," +
            KEY_COMMENTS + " TEXT," +
            "FOREIGN KEY(" + KEY_COURSE_ID + ") REFERENCES " + TABLE_COURSES + "(" + KEY_ID + "))";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_COURSES);
        db.execSQL(CREATE_TABLE_SCHEDULES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCHEDULES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COURSES);
        onCreate(db);
    }

    // ==================== YOGA COURSE OPERATIONS ====================

    public long createCourse(YogaCourse course) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_DAY, course.getDayOfWeek());
        values.put(KEY_TIME, course.getTime());
        values.put(KEY_CAPACITY, course.getCapacity());
        values.put(KEY_DURATION, course.getDuration());
        values.put(KEY_PRICE, course.getPrice());
        values.put(KEY_TYPE, course.getType());
        values.put(KEY_DESCRIPTION, course.getDescription());

        long id = db.insert(TABLE_COURSES, null, values);
        db.close();
        return id;
    }

    @SuppressLint("Range")
    public YogaCourse getCourse(long id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_COURSES,
                null,
                KEY_ID + "=?",
                new String[]{String.valueOf(id)},
                null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            YogaCourse course = new YogaCourse(
                    cursor.getLong(cursor.getColumnIndex(KEY_ID)),
                    cursor.getString(cursor.getColumnIndex(KEY_DAY)),
                    cursor.getString(cursor.getColumnIndex(KEY_TIME)),
                    cursor.getInt(cursor.getColumnIndex(KEY_CAPACITY)),
                    cursor.getInt(cursor.getColumnIndex(KEY_DURATION)),
                    cursor.getDouble(cursor.getColumnIndex(KEY_PRICE)),
                    cursor.getString(cursor.getColumnIndex(KEY_TYPE)),
                    cursor.getString(cursor.getColumnIndex(KEY_DESCRIPTION))
            );
            cursor.close();
            return course;
        }
        return null;
    }

    public int updateCourse(YogaCourse course) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_DAY, course.getDayOfWeek());
        values.put(KEY_TIME, course.getTime());
        values.put(KEY_CAPACITY, course.getCapacity());
        values.put(KEY_DURATION, course.getDuration());
        values.put(KEY_PRICE, course.getPrice());
        values.put(KEY_TYPE, course.getType());
        values.put(KEY_DESCRIPTION, course.getDescription());

        return db.update(TABLE_COURSES, values,
                KEY_ID + " = ?",
                new String[]{String.valueOf(course.getId())});
    }

    public boolean deleteCourse(long id) {
        SQLiteDatabase db = this.getWritableDatabase();

        // First delete all schedules for this course
        db.delete(TABLE_SCHEDULES,
                KEY_COURSE_ID + " = ?",
                new String[]{String.valueOf(id)});

        // Then delete the course
        int deleted = db.delete(TABLE_COURSES,
                KEY_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
        return deleted > 0;
    }

    public Cursor getAllCoursesCursor() {
        String[] columns = {
                KEY_ID + " AS _id",  // This aliases your id column to _id
                KEY_DAY,
                KEY_TIME,
                KEY_CAPACITY,
                KEY_DURATION,
                KEY_PRICE,
                KEY_TYPE,
                KEY_DESCRIPTION
        };

        return getReadableDatabase().query(
                TABLE_COURSES,
                columns,
                null, null, null, null,
                KEY_DAY + ", " + KEY_TIME
        );
    }

    public Cursor searchCoursesByTeacher(String teacherName) {
        String[] columns = {
                TABLE_COURSES + "." + KEY_ID + " AS _id",
                TABLE_COURSES + "." + KEY_DAY,
                TABLE_COURSES + "." + KEY_TIME,
                TABLE_COURSES + "." + KEY_TYPE,
                TABLE_COURSES + "." + KEY_DURATION,
                TABLE_COURSES + "." + KEY_CAPACITY,
                TABLE_COURSES + "." + KEY_PRICE,
                TABLE_COURSES + "." + KEY_DESCRIPTION
        };

        String tables = TABLE_COURSES + " JOIN " + TABLE_SCHEDULES +
                " ON " + TABLE_COURSES + "." + KEY_ID + " = " +
                TABLE_SCHEDULES + "." + KEY_COURSE_ID;

        return getReadableDatabase().query(
                tables,
                columns,
                TABLE_SCHEDULES + "." + KEY_TEACHER + " LIKE ?",
                new String[]{"%" + teacherName + "%"},
                null, null,
                TABLE_COURSES + "." + KEY_DAY + ", " + TABLE_COURSES + "." + KEY_TIME
        );
    }
    public long createSchedule(YogaSchedule schedule) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_COURSE_ID, schedule.getCourseId());
        values.put(KEY_DATE, schedule.getDate());
        values.put(KEY_TEACHER, schedule.getTeacher());
        values.put(KEY_COMMENTS, schedule.getComments());

        long id = db.insert(TABLE_SCHEDULES, null, values);
        db.close();
        return id;
    }

    @SuppressLint("Range")
    public YogaSchedule getSchedule(long id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_SCHEDULES,
                null,
                KEY_ID + "=?",
                new String[]{String.valueOf(id)},
                null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            YogaSchedule schedule = new YogaSchedule(
                    cursor.getLong(cursor.getColumnIndex(KEY_ID)),
                    cursor.getLong(cursor.getColumnIndex(KEY_COURSE_ID)),
                    cursor.getString(cursor.getColumnIndex(KEY_DATE)),
                    cursor.getString(cursor.getColumnIndex(KEY_TEACHER)),
                    cursor.getString(cursor.getColumnIndex(KEY_COMMENTS))
            );
            cursor.close();
            return schedule;
        }
        return null;
    }

    public int updateSchedule(YogaSchedule schedule) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_COURSE_ID, schedule.getCourseId());
        values.put(KEY_DATE, schedule.getDate());
        values.put(KEY_TEACHER, schedule.getTeacher());
        values.put(KEY_COMMENTS, schedule.getComments());

        return db.update(TABLE_SCHEDULES, values,
                KEY_ID + " = ?",
                new String[]{String.valueOf(schedule.getId())});
    }

    public boolean deleteSchedule(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int deleted = db.delete(TABLE_SCHEDULES,
                KEY_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
        return deleted > 0;
    }

    public Cursor getAllSchedulesCursor() {
        String[] columns = {
                TABLE_SCHEDULES + "." + KEY_ID + " AS _id",
                TABLE_SCHEDULES + "." + KEY_DATE,
                TABLE_SCHEDULES + "." + KEY_TEACHER,
                TABLE_SCHEDULES + "." + KEY_COMMENTS,
                TABLE_SCHEDULES + "." + KEY_COURSE_ID,
                TABLE_COURSES + "." + KEY_TYPE,
                TABLE_COURSES + "." + KEY_TIME
        };

        String tables = TABLE_SCHEDULES + " LEFT JOIN " + TABLE_COURSES +
                " ON " + TABLE_SCHEDULES + "." + KEY_COURSE_ID +
                " = " + TABLE_COURSES + "." + KEY_ID;

        return getReadableDatabase().query(
                tables,
                columns,
                null, null, null, null,
                KEY_DATE + " DESC"
        );
    }

    public Cursor searchSchedulesByTeacher(String teacherName) {
        String[] columns = {
                TABLE_SCHEDULES + "." + KEY_ID + " AS _id",
                TABLE_SCHEDULES + "." + KEY_DATE,
                TABLE_SCHEDULES + "." + KEY_TEACHER,
                TABLE_SCHEDULES + "." + KEY_COMMENTS,
                TABLE_SCHEDULES + "." + KEY_COURSE_ID,
                TABLE_COURSES + "." + KEY_TYPE,
                TABLE_COURSES + "." + KEY_TIME
        };

        String tables = TABLE_SCHEDULES + " LEFT JOIN " + TABLE_COURSES +
                " ON " + TABLE_SCHEDULES + "." + KEY_COURSE_ID +
                " = " + TABLE_COURSES + "." + KEY_ID;

        return getReadableDatabase().query(
                tables,
                columns,
                TABLE_SCHEDULES + "." + KEY_TEACHER + " LIKE ?",
                new String[]{"%" + teacherName + "%"},
                null, null,
                KEY_DATE + " DESC"
        );
    }
    public Cursor searchCourses(String searchText) {
        String[] columns = {
                KEY_ID + " AS _id",
                KEY_DAY,
                KEY_TIME,
                KEY_TYPE,
                KEY_DURATION,
                KEY_CAPACITY,
                KEY_PRICE,
                KEY_DESCRIPTION
        };

        String selection = KEY_DAY + " LIKE ? OR " +
                KEY_TIME + " LIKE ? OR " +
                KEY_TYPE + " LIKE ? OR " +
                KEY_DESCRIPTION + " LIKE ?";

        String[] selectionArgs = {
                "%" + searchText + "%",
                "%" + searchText + "%",
                "%" + searchText + "%",
                "%" + searchText + "%"
        };

        return getReadableDatabase().query(
                TABLE_COURSES,
                columns,
                selection,
                selectionArgs,
                null, null,
                KEY_DAY + ", " + KEY_TIME
        );
    }
    public Cursor searchSchedulesForCourse(long courseId, String teacherSearch) {
        String[] columns = {
                TABLE_SCHEDULES + "." + KEY_ID + " AS _id",
                TABLE_SCHEDULES + "." + KEY_DATE,
                TABLE_SCHEDULES + "." + KEY_TEACHER,
                TABLE_SCHEDULES + "." + KEY_COMMENTS,
                TABLE_SCHEDULES + "." + KEY_COURSE_ID,
                TABLE_COURSES + "." + KEY_TYPE,
                TABLE_COURSES + "." + KEY_TIME
        };

        String tables = TABLE_SCHEDULES + " LEFT JOIN " + TABLE_COURSES +
                " ON " + TABLE_SCHEDULES + "." + KEY_COURSE_ID +
                " = " + TABLE_COURSES + "." + KEY_ID;

        String selection = TABLE_SCHEDULES + "." + KEY_COURSE_ID + " = ?";
        String[] selectionArgs = {String.valueOf(courseId)};

        if (teacherSearch != null && !teacherSearch.isEmpty()) {
            selection += " AND " + TABLE_SCHEDULES + "." + KEY_TEACHER + " LIKE ?";
            selectionArgs = new String[]{String.valueOf(courseId), "%" + teacherSearch + "%"};
        }

        return getReadableDatabase().query(
                tables,
                columns,
                selection,
                selectionArgs,
                null, null,
                KEY_DATE + " DESC"
        );
    }
    public Cursor searchSchedules(String searchText, long courseId) {
        String[] columns = {
                TABLE_SCHEDULES + "." + KEY_ID + " AS _id",
                TABLE_SCHEDULES + "." + KEY_DATE,
                TABLE_SCHEDULES + "." + KEY_TEACHER,
                TABLE_SCHEDULES + "." + KEY_COMMENTS,
                TABLE_SCHEDULES + "." + KEY_COURSE_ID,
                TABLE_COURSES + "." + KEY_TYPE,
                TABLE_COURSES + "." + KEY_TIME
        };

        String tables = TABLE_SCHEDULES + " LEFT JOIN " + TABLE_COURSES +
                " ON " + TABLE_SCHEDULES + "." + KEY_COURSE_ID +
                " = " + TABLE_COURSES + "." + KEY_ID;

        String selection = "(" + TABLE_SCHEDULES + "." + KEY_TEACHER + " LIKE ? OR " +
                TABLE_SCHEDULES + "." + KEY_DATE + " LIKE ? OR " +
                TABLE_SCHEDULES + "." + KEY_COMMENTS + " LIKE ? OR " +
                TABLE_COURSES + "." + KEY_TYPE + " LIKE ?)";

        if (courseId != -1) {
            selection += " AND " + TABLE_SCHEDULES + "." + KEY_COURSE_ID + " = ?";
        }

        String[] selectionArgs;
        if (courseId != -1) {
            selectionArgs = new String[]{
                    "%" + searchText + "%",
                    "%" + searchText + "%",
                    "%" + searchText + "%",
                    "%" + searchText + "%",
                    String.valueOf(courseId)
            };
        } else {
            selectionArgs = new String[]{
                    "%" + searchText + "%",
                    "%" + searchText + "%",
                    "%" + searchText + "%",
                    "%" + searchText + "%"
            };
        }

        return getReadableDatabase().query(
                tables,
                columns,
                selection,
                selectionArgs,
                null, null,
                TABLE_SCHEDULES + "." + KEY_DATE + " DESC"
        );
    }
}