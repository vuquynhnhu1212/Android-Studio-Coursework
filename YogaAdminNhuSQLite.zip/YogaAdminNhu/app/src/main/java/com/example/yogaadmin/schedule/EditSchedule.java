package com.example.yogaadmin.schedule;

import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.DatabaseHelper;
import com.example.yogaadmin.R;

import java.util.Calendar;

public class EditSchedule extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private DatePicker datePicker;
    private long scheduleId;
    private long courseId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_yoga_schedule);

        dbHelper = new DatabaseHelper(this);
        datePicker = findViewById(R.id.dpScheduleEdit);

        // Get schedule ID from intent
        scheduleId = getIntent().getLongExtra("SCHEDULE_ID", -1);
        if (scheduleId == -1) {
            Toast.makeText(this, "Invalid schedule", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Load schedule data
        YogaSchedule schedule = dbHelper.getSchedule(scheduleId);
        if (schedule == null) {
            Toast.makeText(this, "Schedule not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        courseId = schedule.getCourseId();
        populateForm(schedule);
    }

    private void populateForm(YogaSchedule schedule) {
        ((EditText) findViewById(R.id.etTeacherEdit)).setText(schedule.getTeacher());

        if (schedule.getComments() != null) {
            ((EditText) findViewById(R.id.edmCommentEdit)).setText(schedule.getComments());
        }

        // Parse and set date
        String[] dateParts = schedule.getDate().split("/");
        datePicker.updateDate(
                Integer.parseInt(dateParts[2]),  // year
                Integer.parseInt(dateParts[1]) - 1,  // month (0-based)
                Integer.parseInt(dateParts[0])   // day
        );
    }

    public void onClickEditSchedule(View v) {
        EditText etTeacherEdit = findViewById(R.id.etTeacherEdit);
        EditText edtCommentEdit = findViewById(R.id.edmCommentEdit);

        String teacher = etTeacherEdit.getText().toString().trim();
        String comments = edtCommentEdit.getText().toString().trim();

        if (teacher.isEmpty()) {
            Toast.makeText(this, "Please enter teacher name", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get date from DatePicker
        String date = String.format("%02d/%02d/%04d",
                datePicker.getDayOfMonth(),
                datePicker.getMonth() + 1,
                datePicker.getYear());

        // Update schedule
        YogaSchedule schedule = new YogaSchedule();
        schedule.setId(scheduleId);
        schedule.setCourseId(courseId);
        schedule.setDate(date);
        schedule.setTeacher(teacher);
        schedule.setComments(comments.isEmpty() ? null : comments);

        if (dbHelper.updateSchedule(schedule) > 0) {
            Toast.makeText(this, "Schedule updated", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to update schedule", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClickClearSchedule(View v) {
        YogaSchedule schedule = dbHelper.getSchedule(scheduleId);
        if (schedule != null) {
            populateForm(schedule);
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}