package com.example.yogaadmin;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ResourceCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.course.CreateYogaCourse;
import com.example.yogaadmin.course.EditYogaCourse;
import com.example.yogaadmin.course.YogaCourse;

public class MainActivity extends AppCompatActivity {
    public static DatabaseHelper helper;
    private EditText etSearchCourse;
    private Button btnSearchCourse;
    private YogaCourseCursorAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        helper = new DatabaseHelper(this);
        etSearchCourse = findViewById(R.id.etSearchCourse);
        btnSearchCourse = findViewById(R.id.btnSearchCourse);

        btnSearchCourse.setOnClickListener(v -> {
            String searchText = etSearchCourse.getText().toString().trim();
            Cursor cursor = helper.searchCourses(searchText);

            if (adapter == null) {
                adapter = new YogaCourseCursorAdapter(this, R.layout.yoga_course_item, cursor, 0);
                ListView lv = findViewById(R.id.lvCourse);
                lv.setAdapter(adapter);
            } else {
                adapter.changeCursor(cursor);
            }
        });

        refreshCourseList();
    }

    public void onCreateYogaCourse(View v) {
        startActivity(new Intent(this, CreateYogaCourse.class));
    }

    public void onMainActivitySchedule(View v) {
        startActivity(new Intent(this, CourseSelectionActivity.class));
    }

    @Override
    protected void onStart() {
        super.onStart();
        refreshCourseList();
    }

    public void refreshCourseList() {
        runOnUiThread(() -> {
            Cursor cursor = helper.getAllCoursesCursor();
            if (adapter == null) {
                adapter = new YogaCourseCursorAdapter(
                        this,
                        R.layout.yoga_course_item,
                        cursor,
                        0
                );
                ListView lv = findViewById(R.id.lvCourse);
                lv.setAdapter(adapter);
            } else {
                adapter.changeCursor(cursor);
            }
        });
    }

    @Override
    protected void onDestroy() {
        helper.close();
        super.onDestroy();
    }

    static class YogaCourseCursorAdapter extends ResourceCursorAdapter {
        private final MainActivity activity;

        public YogaCourseCursorAdapter(Context context, int layout, Cursor cursor, int flags) {
            super(context, layout, cursor, flags);
            this.activity = (MainActivity) context;
        }

        @SuppressLint("Range")
        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            long id = cursor.getLong(cursor.getColumnIndex("_id"));
            String day = cursor.getString(cursor.getColumnIndex("day"));
            String time = cursor.getString(cursor.getColumnIndex("time"));
            String type = cursor.getString(cursor.getColumnIndex("type"));
            int duration = cursor.getInt(cursor.getColumnIndex("duration"));
            int capacity = cursor.getInt(cursor.getColumnIndex("capacity"));
            double price = cursor.getDouble(cursor.getColumnIndex("price"));
            String description = cursor.getString(cursor.getColumnIndex("description"));

            YogaCourse course = new YogaCourse(id, day, time, capacity, duration, price, type, description);

            TextView tvDay = view.findViewById(R.id.tvDayOfWeek);
            TextView tvType = view.findViewById(R.id.tvType);
            TextView tvTime = view.findViewById(R.id.tvTime);
            TextView tvDuration = view.findViewById(R.id.tvDuration);
            TextView tvCapacity = view.findViewById(R.id.tvCapacity);
            TextView tvDescription = view.findViewById(R.id.tvDescription);
            TextView tvPrice = view.findViewById(R.id.tvPrice);
            Button btnDelete = view.findViewById(R.id.btnDeleteCourse);
            Button btnEdit = view.findViewById(R.id.btnEditCourse);

            tvDay.setText(day);
            tvType.setText(type);
            tvTime.setText(time);
            tvDuration.setText(String.format("%d mins", duration));
            tvCapacity.setText(String.valueOf(capacity));
            tvDescription.setText(description);
            tvPrice.setText(String.format("£%.2f", price));

            btnDelete.setOnClickListener(v -> showDeleteDialog(context, course));
            btnEdit.setOnClickListener(v -> openEditActivity(context, course));
        }

        private void showDeleteDialog(Context context, YogaCourse course) {
            new AlertDialog.Builder(context)
                    .setTitle("Delete Course")
                    .setMessage("Delete " + course.getType() + " on " + course.getDayOfWeek() + "?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        if (MainActivity.helper.deleteCourse(course.getId())) {
                            Toast.makeText(context, "Course deleted", Toast.LENGTH_SHORT).show();
                            activity.refreshCourseList();
                        } else {
                            Toast.makeText(context, "Failed to delete course", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }

        private void openEditActivity(Context context, YogaCourse course) {
            Intent intent = new Intent(context, EditYogaCourse.class);
            intent.putExtra("COURSE_ID", course.getId());
            context.startActivity(intent);
        }
    }
}