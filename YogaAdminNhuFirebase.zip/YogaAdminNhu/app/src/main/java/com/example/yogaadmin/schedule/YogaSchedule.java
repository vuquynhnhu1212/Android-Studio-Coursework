package com.example.yogaadmin.schedule;

import com.example.yogaadmin.course.YogaCourse;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;
import java.util.HashMap;
import java.util.Map;

@IgnoreExtraProperties
public class YogaSchedule {
    private String id;
    private String courseId;    // Reference to YogaCourse
    private String date;
    private String teacher;
    private String comments;

    // Required empty constructor for Firebase
    public YogaSchedule() {
        // Default constructor required for calls to DataSnapshot.getValue(YogaSchedule.class)
    }

    // Constructor without ID (Firebase will generate this)
    public YogaSchedule(String courseId, String date, String teacher, String comments) {
        this.courseId = courseId;
        this.date = date;
        this.teacher = teacher;
        this.comments = (comments == null || comments.trim().isEmpty()) ? null : comments.trim();
    }

    // Full constructor (useful when retrieving existing records)
    public YogaSchedule(String id, String courseId, String date, String teacher, String comments) {
        this.id = id;
        this.courseId = courseId;
        this.date = date;
        this.teacher = teacher;
        this.comments = (comments == null || comments.trim().isEmpty()) ? null : comments.trim();
    }

    // Converts the object to a Map for Firebase
    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("courseId", courseId);
        result.put("date", date);
        result.put("teacher", teacher);
        result.put("comments", comments);

        // Note: We don't include id in the map because Firebase will handle this as the key
        return result;
    }

    // Getters and Setters
    @Exclude
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = (comments == null || comments.trim().isEmpty()) ? null : comments.trim();
    }

    // These methods would require fetching the YogaCourse from Firebase
    @Exclude
    public String getCourseType(YogaCourse course) {
        return course != null ? course.getType() : null;
    }

    @Exclude
    public String getCourseTime(YogaCourse course) {
        return course != null ? course.getTime() : null;
    }

    @Override
    public String toString() {
        return "Scheduled on " + date + " with " + teacher +
                (comments != null ? " (" + comments + ")" : "");
    }

    // Helper method to create a more detailed string when course info is available
    @Exclude
    public String toStringWithCourseInfo(YogaCourse course) {
        return (course != null ? course.getType() + " " : "") +
                "Scheduled on " + date +
                (course != null ? " at " + course.getTime() : "") +
                " with " + teacher +
                (comments != null ? " (" + comments + ")" : "");
    }
}