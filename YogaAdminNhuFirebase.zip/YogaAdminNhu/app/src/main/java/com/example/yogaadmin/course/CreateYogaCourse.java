package com.example.yogaadmin.course;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.FirebaseDatabaseHelper;
import com.example.yogaadmin.R;
import com.example.yogaadmin.course.YogaCourse;

public class CreateYogaCourse extends AppCompatActivity {

    private FirebaseDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_yoga_course);

        // Initialize FirebaseDatabaseHelper
        dbHelper = new FirebaseDatabaseHelper(this);
    }

    public void onClickCreateYogaCourse(View v) {
        // Get values from form
        Spinner spDay = findViewById(R.id.spDayOfWeek);
        Spinner spTime = findViewById(R.id.spTime);
        Spinner spType = findViewById(R.id.spType);
        Spinner spDuration = findViewById(R.id.spDuration);
        EditText edPrice = findViewById(R.id.edPrice);
        EditText edCapacity = findViewById(R.id.edCapacity);
        EditText edDescription = findViewById(R.id.edmDes);

        try {
            // Validate inputs
            String dayOfWeek = spDay.getSelectedItem().toString();
            String time = spTime.getSelectedItem().toString();
            String type = spType.getSelectedItem().toString();
            String durationStr = spDuration.getSelectedItem().toString();
            String description = edDescription.getText().toString();

            // Parse numerical values
            int duration = Integer.parseInt(durationStr.replaceAll("[^0-9]", ""));
            int capacity = Integer.parseInt(edCapacity.getText().toString());
            double price = Double.parseDouble(edPrice.getText().toString());

            // Create YogaCourse object
            YogaCourse course = new YogaCourse(
                    dayOfWeek,
                    time,
                    capacity,
                    duration,
                    price,
                    type,
                    description
            );

            // Add to Firebase database
            dbHelper.createCourse(course, new FirebaseDatabaseHelper.DatabaseCallback() {
                @Override
                public void onSuccess(Object result) {
                    runOnUiThread(() -> {
                        String courseId = (String) result;
                        Toast.makeText(CreateYogaCourse.this,
                                "Yoga class created successfully! ID: " + courseId,
                                Toast.LENGTH_LONG).show();
                        finish(); // Close activity after successful creation
                    });
                }

                @Override
                public void onError(Exception e) {
                    runOnUiThread(() -> {
                        Toast.makeText(CreateYogaCourse.this,
                                "Failed to create yoga class: " + e.getMessage(),
                                Toast.LENGTH_LONG).show();
                    });
                }
            });

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numbers for capacity and price", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void onClickClearYogaCourse(View v) {
        clearForm();
    }

    private void clearForm() {
        // Clear all text input fields
        ((EditText) findViewById(R.id.edPrice)).setText("");
        ((EditText) findViewById(R.id.edCapacity)).setText("");
        ((EditText) findViewById(R.id.edmDes)).setText("");

        // Reset all spinners to their first position
        ((Spinner) findViewById(R.id.spDayOfWeek)).setSelection(0);
        ((Spinner) findViewById(R.id.spTime)).setSelection(0);
        ((Spinner) findViewById(R.id.spType)).setSelection(0);
        ((Spinner) findViewById(R.id.spDuration)).setSelection(0);

        // Optionally set focus to the first field
        findViewById(R.id.spDayOfWeek).requestFocus();

        // Show confirmation to user
        Toast.makeText(this, "Form cleared", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        // No need to close Firebase connection explicitly
        super.onDestroy();
    }
}