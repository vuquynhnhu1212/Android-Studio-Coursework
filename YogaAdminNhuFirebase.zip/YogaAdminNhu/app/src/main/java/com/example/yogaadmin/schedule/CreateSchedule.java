package com.example.yogaadmin.schedule;

import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.FirebaseDatabaseHelper;
import com.example.yogaadmin.R;
import com.example.yogaadmin.course.YogaCourse;

import java.util.Calendar;

public class CreateSchedule extends AppCompatActivity {
    private FirebaseDatabaseHelper dbHelper;
    private DatePicker datePicker;
    private String courseId; // Changed to String for Firebase
    private YogaCourse currentCourse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_yoga_schedule);

        // Get course ID from intent
        courseId = getIntent().getStringExtra("COURSE_ID");
        if (courseId == null || courseId.isEmpty()) {
            Toast.makeText(this, "No course selected", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        dbHelper = new FirebaseDatabaseHelper(this);
        datePicker = findViewById(R.id.dpSchedule);

        // Load course details to determine day of week
        loadCourseDetails();
    }

    private void loadCourseDetails() {
        dbHelper.getCourse(courseId, new FirebaseDatabaseHelper.DatabaseCallback() {
            @Override
            public void onSuccess(Object result) {
                currentCourse = (YogaCourse) result;
                runOnUiThread(() -> {
                    if (currentCourse != null) {
                        initializeDatePicker();
                    } else {
                        Toast.makeText(CreateSchedule.this,
                                "Course not found", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
            }

            @Override
            public void onError(Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(CreateSchedule.this,
                            "Error loading course: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                    finish();
                });
            }
        });
    }

    private void initializeDatePicker() {
        Calendar calendar = Calendar.getInstance();
        setToNextDayOfWeek(calendar, currentCourse.getDayOfWeek());
        datePicker.init(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH), null);
    }

    private void setToNextDayOfWeek(Calendar calendar, String dayOfWeek) {
        int targetDay = convertDayOfWeekToCalendar(dayOfWeek);
        int currentDay = calendar.get(Calendar.DAY_OF_WEEK);

        // Calculate days to add to get to the next occurrence of target day
        int daysToAdd = (targetDay - currentDay + 7) % 7;
        if (daysToAdd == 0) daysToAdd = 7; // If today is the day, go to next week

        calendar.add(Calendar.DAY_OF_YEAR, daysToAdd);
    }

    private int convertDayOfWeekToCalendar(String dayOfWeek) {
        switch (dayOfWeek.toLowerCase()) {
            case "monday": return Calendar.MONDAY;
            case "tuesday": return Calendar.TUESDAY;
            case "wednesday": return Calendar.WEDNESDAY;
            case "thursday": return Calendar.THURSDAY;
            case "friday": return Calendar.FRIDAY;
            case "saturday": return Calendar.SATURDAY;
            case "sunday": return Calendar.SUNDAY;
            default: return Calendar.MONDAY;
        }
    }

    public void onClickAddSchedule(View v) {
        EditText etTeacher = findViewById(R.id.etTeacher);
        EditText etComment = findViewById(R.id.edmComment);

        String teacher = etTeacher.getText().toString().trim();
        String comment = etComment.getText().toString().trim();

        if (teacher.isEmpty()) {
            Toast.makeText(this, "Please enter teacher name", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get selected date
        String date = String.format("%02d/%02d/%04d",
                datePicker.getDayOfMonth(),
                datePicker.getMonth() + 1,
                datePicker.getYear());

        // Create new schedule
        YogaSchedule schedule = new YogaSchedule(
                courseId,
                date,
                teacher,
                comment.isEmpty() ? null : comment
        );

        // Add to Firebase
        dbHelper.createSchedule(schedule, new FirebaseDatabaseHelper.DatabaseCallback() {
            @Override
            public void onSuccess(Object result) {
                runOnUiThread(() -> {
                    String scheduleId = (String) result;
                    Toast.makeText(CreateSchedule.this,
                            "Schedule created! ID: " + scheduleId,
                            Toast.LENGTH_LONG).show();
                    finish();
                });
            }

            @Override
            public void onError(Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(CreateSchedule.this,
                            "Failed to create schedule: " + e.getMessage(),
                            Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    public void onClickClearSchedule(View v) {
        clearForm();
    }

    private void clearForm() {
        ((EditText) findViewById(R.id.etTeacher)).setText("");
        ((EditText) findViewById(R.id.edmComment)).setText("");

        // Reset to next valid date if course is loaded
        if (currentCourse != null) {
            Calendar calendar = Calendar.getInstance();
            setToNextDayOfWeek(calendar, currentCourse.getDayOfWeek());
            datePicker.updateDate(calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH));
        }
    }

    @Override
    protected void onDestroy() {
        // No need to close Firebase connection explicitly
        super.onDestroy();
    }
}