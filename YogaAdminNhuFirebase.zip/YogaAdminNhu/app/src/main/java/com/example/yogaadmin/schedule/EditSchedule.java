package com.example.yogaadmin.schedule;

import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.FirebaseDatabaseHelper;
import com.example.yogaadmin.R;

public class EditSchedule extends AppCompatActivity {
    private FirebaseDatabaseHelper dbHelper;
    private DatePicker datePicker;
    private String scheduleId; // Changed to String for Firebase
    private String courseId;   // Changed to String for Firebase
    private YogaSchedule currentSchedule;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_yoga_schedule);

        dbHelper = new FirebaseDatabaseHelper(this);
        datePicker = findViewById(R.id.dpScheduleEdit);

        // Get schedule ID from intent
        scheduleId = getIntent().getStringExtra("SCHEDULE_ID");
        if (scheduleId == null || scheduleId.isEmpty()) {
            Toast.makeText(this, "Invalid schedule", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Load schedule data from Firebase
        loadScheduleData();
    }

    private void loadScheduleData() {
        dbHelper.getSchedule(scheduleId, new FirebaseDatabaseHelper.DatabaseCallback() {
            @Override
            public void onSuccess(Object result) {
                currentSchedule = (YogaSchedule) result;
                runOnUiThread(() -> {
                    if (currentSchedule != null) {
                        courseId = currentSchedule.getCourseId();
                        populateForm(currentSchedule);
                    } else {
                        Toast.makeText(EditSchedule.this,
                                "Schedule not found", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                });
            }

            @Override
            public void onError(Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(EditSchedule.this,
                            "Error loading schedule: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                    finish();
                });
            }
        });
    }

    private void populateForm(YogaSchedule schedule) {
        ((EditText) findViewById(R.id.etTeacherEdit)).setText(schedule.getTeacher());

        if (schedule.getComments() != null) {
            ((EditText) findViewById(R.id.edmCommentEdit)).setText(schedule.getComments());
        }

        // Parse and set date
        String[] dateParts = schedule.getDate().split("/");
        datePicker.updateDate(
                Integer.parseInt(dateParts[2]),  // year
                Integer.parseInt(dateParts[1]) - 1,  // month (0-based)
                Integer.parseInt(dateParts[0])   // day
        );
    }

    public void onClickEditSchedule(View v) {
        EditText etTeacherEdit = findViewById(R.id.etTeacherEdit);
        EditText edtCommentEdit = findViewById(R.id.edmCommentEdit);

        String teacher = etTeacherEdit.getText().toString().trim();
        String comments = edtCommentEdit.getText().toString().trim();

        if (teacher.isEmpty()) {
            Toast.makeText(this, "Please enter teacher name", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get date from DatePicker
        String date = String.format("%02d/%02d/%04d",
                datePicker.getDayOfMonth(),
                datePicker.getMonth() + 1,
                datePicker.getYear());

        // Update schedule
        YogaSchedule updatedSchedule = new YogaSchedule(
                scheduleId,
                courseId,
                date,
                teacher,
                comments.isEmpty() ? null : comments
        );

        // Update in Firebase
        dbHelper.updateSchedule(updatedSchedule, new FirebaseDatabaseHelper.DatabaseCallback() {
            @Override
            public void onSuccess(Object result) {
                runOnUiThread(() -> {
                    Toast.makeText(EditSchedule.this,
                            "Schedule updated successfully",
                            Toast.LENGTH_SHORT).show();
                    finish();
                });
            }

            @Override
            public void onError(Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(EditSchedule.this,
                            "Failed to update schedule: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    public void onClickClearSchedule(View v) {
        if (currentSchedule != null) {
            populateForm(currentSchedule);
            Toast.makeText(this, "Changes discarded", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        // No need to close Firebase connection explicitly
        super.onDestroy();
    }
}