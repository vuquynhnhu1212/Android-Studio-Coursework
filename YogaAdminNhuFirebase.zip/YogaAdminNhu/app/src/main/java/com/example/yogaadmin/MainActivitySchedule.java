package com.example.yogaadmin;

import static com.example.yogaadmin.MainActivity.helper;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.course.YogaCourse;
import com.example.yogaadmin.schedule.CreateSchedule;
import com.example.yogaadmin.schedule.EditSchedule;
import com.example.yogaadmin.schedule.YogaSchedule;
import com.example.yogaadmin.FirebaseDatabaseHelper.DataLoadCallback;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivitySchedule extends AppCompatActivity {
    private EditText etSearchSchedule;
    private Button btnSearchSchedule;
    private YogaScheduleAdapter adapter;
    private List<YogaSchedule> schedules = new ArrayList<>();
    private String selectedCourseId;
    private String searchQuery = "";
    private YogaCourse currentCourse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_schedule);

        selectedCourseId = getIntent().getStringExtra("SELECTED_COURSE_ID");
        if (selectedCourseId == null || selectedCourseId.isEmpty()) {
            Toast.makeText(this, "No course selected", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        if (helper == null) {
            Toast.makeText(this, "Database helper not initialized", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadCourseInfo();

        etSearchSchedule = findViewById(R.id.etSearchSchedule);
        btnSearchSchedule = findViewById(R.id.btnSearchSchedule);
        ListView lvSchedule = findViewById(R.id.lvSchedule);

        adapter = new YogaScheduleAdapter(this, schedules);
        lvSchedule.setAdapter(adapter);

        btnSearchSchedule.setOnClickListener(v -> {
            searchQuery = etSearchSchedule.getText().toString().trim();
            loadSchedules();
        });

        loadSchedules();
    }

    private void loadCourseInfo() {
        DatabaseReference courseRef = FirebaseDatabase.getInstance().getReference("courses").child(selectedCourseId);
        courseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                currentCourse = dataSnapshot.getValue(YogaCourse.class);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(MainActivitySchedule.this, "Failed to load course info", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void onCreateYogaSchedule(View v) {
        Intent intent = new Intent(this, CreateSchedule.class);
        intent.putExtra("COURSE_ID", selectedCourseId);
        startActivity(intent);
    }

    public void onReturn(View v) {
        finish();
    }

    @Override
    protected void onStart() {
        super.onStart();
        loadSchedules();
    }

    private void loadSchedules() {
        if (searchQuery.isEmpty()) {
            helper.searchSchedulesForCourse(selectedCourseId, null, new DataLoadCallback<YogaSchedule>() {
                @Override
                public void onDataLoaded(List<YogaSchedule> data) {
                    updateScheduleList(data);
                }

                @Override
                public void onError(Exception e) {
                    e.printStackTrace();
                    showError("Error loading schedules: " + e.getMessage());
                }
            });
        } else {
            helper.searchSchedules(searchQuery, selectedCourseId, new DataLoadCallback<YogaSchedule>() {
                @Override
                public void onDataLoaded(List<YogaSchedule> data) {
                    updateScheduleList(data);
                }

                @Override
                public void onError(Exception e) {
                    e.printStackTrace();
                    showError("Error searching schedules: " + e.getMessage());
                }
            });
        }
    }

    private void updateScheduleList(List<YogaSchedule> data) {
        runOnUiThread(() -> {
            schedules.clear();
            schedules.addAll(data);
            adapter.notifyDataSetChanged();

            if (data.isEmpty()) {
                Toast.makeText(MainActivitySchedule.this, "No schedules found", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showError(String message) {
        runOnUiThread(() ->
                Toast.makeText(MainActivitySchedule.this, message, Toast.LENGTH_SHORT).show());
    }

    private void confirmDeleteSchedule(Context context, String scheduleId) {
        new AlertDialog.Builder(context)
                .setTitle("Delete Schedule")
                .setMessage("Are you sure you want to delete this schedule?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    helper.deleteSchedule(scheduleId, new FirebaseDatabaseHelper.DatabaseCallback() {
                        @Override
                        public void onSuccess(Object result) {
                            runOnUiThread(() -> {
                                Toast.makeText(context, "Schedule deleted", Toast.LENGTH_SHORT).show();
                                loadSchedules();
                            });
                        }

                        @Override
                        public void onError(Exception e) {
                            e.printStackTrace();
                            runOnUiThread(() -> Toast.makeText(context,
                                    "Failed to delete schedule: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show());
                        }
                    });
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void openEditSchedule(Context context, String scheduleId) {
        Intent intent = new Intent(context, EditSchedule.class);
        intent.putExtra("SCHEDULE_ID", scheduleId);
        context.startActivity(intent);
    }

    class YogaScheduleAdapter extends BaseAdapter {
        private final Context context;
        private final List<YogaSchedule> schedules;
        private final LayoutInflater inflater;

        YogaScheduleAdapter(Context context, List<YogaSchedule> schedules) {
            this.context = context;
            this.schedules = schedules;
            this.inflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return schedules.size();
        }

        @Override
        public YogaSchedule getItem(int position) {
            return schedules.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @SuppressLint("SetTextI18n")
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = inflater.inflate(R.layout.yoga_schedule_item, parent, false);
            }

            YogaSchedule schedule = getItem(position);

            TextView tvDate = view.findViewById(R.id.tvDate);
            TextView tvTeacher = view.findViewById(R.id.tvTeacher);
            TextView tvComments = view.findViewById(R.id.tvComments);
            TextView tvCourseInfo = view.findViewById(R.id.tvCourseId);
            Button btnDelete = view.findViewById(R.id.btnDeleteSchedule);
            Button btnEdit = view.findViewById(R.id.btnEditSchedule);

            tvDate.setText(schedule.getDate());
            tvTeacher.setText(schedule.getTeacher());
            tvComments.setText(schedule.getComments() != null ? schedule.getComments() : "");

            if (currentCourse != null && currentCourse.getType() != null && currentCourse.getTime() != null) {
                tvCourseInfo.setText(currentCourse.getType() + " at " + currentCourse.getTime());
            } else {
                tvCourseInfo.setText("Course info unavailable");
            }

            btnDelete.setOnClickListener(v -> confirmDeleteSchedule(context, schedule.getId()));
            btnEdit.setOnClickListener(v -> openEditSchedule(context, schedule.getId()));

            return view;
        }
    }
}
