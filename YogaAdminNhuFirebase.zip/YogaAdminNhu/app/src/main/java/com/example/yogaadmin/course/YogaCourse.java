package com.example.yogaadmin.course;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.HashMap;
import java.util.Map;

@IgnoreExtraProperties
public class YogaCourse {
    private String id;  // Changed from long to String for Firebase
    private String dayOfWeek;  // Monday, Tuesday, etc.
    private String time;       // 10:00, 11:00, etc.
    private int capacity;      // Maximum attendees
    private int duration;      // In minutes
    private double price;      // Price per class
    private String type;       // Flow Yoga, Aerial Yoga, etc.
    private String description; // Optional description

    // Required empty constructor for Firebase
    public YogaCourse() {
        // Default constructor required for calls to DataSnapshot.getValue(YogaCourse.class)
    }

    // Constructor without ID (Firebase will generate this)
    public YogaCourse(String dayOfWeek, String time, int capacity, int duration,
                      double price, String type, String description) {
        this.dayOfWeek = dayOfWeek;
        this.time = time;
        this.capacity = capacity;
        this.duration = duration;
        this.price = price;
        this.type = type;
        this.description = description;
    }

    // Full constructor (useful when retrieving existing records)
    public YogaCourse(String id, String dayOfWeek, String time, int capacity, int duration,
                      double price, String type, String description) {
        this.id = id;
        this.dayOfWeek = dayOfWeek;
        this.time = time;
        this.capacity = capacity;
        this.duration = duration;
        this.price = price;
        this.type = type;
        this.description = description;
    }

    // Converts the object to a Map for Firebase
    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("dayOfWeek", dayOfWeek);
        result.put("time", time);
        result.put("capacity", capacity);
        result.put("duration", duration);
        result.put("price", price);
        result.put("type", type);
        result.put("description", description);

        // Note: We don't include id in the map because Firebase will handle this as the key
        return result;
    }

    // Getters and Setters
    @Exclude
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // Helper method to display course information
    @Override
    public String toString() {
        return dayOfWeek + " at " + time + " - " + type + " (" + duration + " mins, £" + price + ")";
    }
}