package com.example.yogaadmin;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.course.YogaCourse;
import com.example.yogaadmin.FirebaseDatabaseHelper.DataLoadCallback;

import java.util.ArrayList;
import java.util.List;

public class CourseSelectionActivity extends AppCompatActivity {
    private static final String TAG = "CourseSelection";
    private FirebaseDatabaseHelper dbHelper;
    private CourseAdapter adapter;
    private List<YogaCourse> courses = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_select);

        dbHelper = new FirebaseDatabaseHelper(this);
        ListView lvCourses = findViewById(R.id.lvCourseSelection);

        // Initialize adapter with empty list
        adapter = new CourseAdapter(this, courses);
        lvCourses.setAdapter(adapter);

        // Load initial data
        loadCourseData("");

        // Set item click listener
        lvCourses.setOnItemClickListener((parent, view, position, id) -> {
            // Highlight selection
            for (int i = 0; i < parent.getChildCount(); i++) {
                parent.getChildAt(i).setBackgroundColor(
                        getResources().getColor(android.R.color.transparent));
            }
            view.setBackgroundColor(
                    getResources().getColor(android.R.color.holo_blue_light));

            // Get selected course
            YogaCourse selectedCourse = courses.get(position);

            // Open schedule with selected course ID
            Intent intent = new Intent(CourseSelectionActivity.this, MainActivitySchedule.class);
            intent.putExtra("SELECTED_COURSE_ID", selectedCourse.getId());
            startActivity(intent);
        });

        // Search button
        findViewById(R.id.btnSearchCourse).setOnClickListener(v -> {
            String searchText = ((EditText) findViewById(R.id.etSearchCourse)).getText().toString().trim();
            loadCourseData(searchText);
        });
    }

    public void onBackButtonClicked(View view) {
        finish();
    }

    private void loadCourseData(String searchText) {
        if (searchText.isEmpty()) {
            dbHelper.getAllCourses(new DataLoadCallback<YogaCourse>() {
                @Override
                public void onDataLoaded(List<YogaCourse> data) {
                    courses.clear();
                    courses.addAll(data);
                    adapter.notifyDataSetChanged();
                    Log.d(TAG, "Loaded " + data.size() + " courses");
                }

                @Override
                public void onError(Exception e) {
                    Toast.makeText(CourseSelectionActivity.this,
                            "Error loading courses: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            dbHelper.searchCourses(searchText, new DataLoadCallback<YogaCourse>() {
                @Override
                public void onDataLoaded(List<YogaCourse> data) {
                    courses.clear();
                    courses.addAll(data);
                    adapter.notifyDataSetChanged();
                    Log.d(TAG, "Found " + data.size() + " matching courses");
                }

                @Override
                public void onError(Exception e) {
                    Toast.makeText(CourseSelectionActivity.this,
                            "Error searching courses: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        // No need to close Firebase connection explicitly
        super.onDestroy();
    }

    class CourseAdapter extends BaseAdapter {
        private final Context context;
        private final List<YogaCourse> courses;
        private final LayoutInflater inflater;

        CourseAdapter(Context context, List<YogaCourse> courses) {
            this.context = context;
            this.courses = courses;
            this.inflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return courses.size();
        }

        @Override
        public YogaCourse getItem(int position) {
            return courses.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position; // Not using SQLite IDs anymore
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = convertView;
            if (view == null) {
                view = inflater.inflate(R.layout.course_list_item, parent, false);
            }

            YogaCourse course = getItem(position);

            TextView tvType = view.findViewById(R.id.tvType);
            TextView tvTime = view.findViewById(R.id.tvTime);
            TextView tvDay = view.findViewById(R.id.tvDayOfWeek);
            TextView tvDuration = view.findViewById(R.id.tvDuration);
            TextView tvCapacity = view.findViewById(R.id.tvCapacity);
            TextView tvDescription = view.findViewById(R.id.tvDescription);
            TextView tvPrice = view.findViewById(R.id.tvPrice);

            tvType.setText(course.getType());
            tvTime.setText(course.getTime());
            tvDay.setText(course.getDayOfWeek());
            tvDuration.setText(course.getDuration() + " mins");
            tvCapacity.setText(String.valueOf(course.getCapacity()));
            tvDescription.setText(course.getDescription());
            tvPrice.setText(String.format("£%.2f", course.getPrice()));

            return view;
        }
    }
}