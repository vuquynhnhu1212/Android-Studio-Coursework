package com.example.yogaadmin.course;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.example.yogaadmin.FirebaseDatabaseHelper;
import com.example.yogaadmin.R;

public class EditYogaCourse extends AppCompatActivity {
    private FirebaseDatabaseHelper dbHelper;
    private YogaCourse currentCourse;
    private Spinner spDayEdit, spTimeEdit, spTypeEdit, spDurationEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_yoga_course);

        // Initialize FirebaseDatabaseHelper
        dbHelper = new FirebaseDatabaseHelper(this);

        // Initialize spinners
        spDayEdit = findViewById(R.id.spDayOfWeekEdit);
        spTimeEdit = findViewById(R.id.spTimeEdit);
        spTypeEdit = findViewById(R.id.spinner2);
        spDurationEdit = findViewById(R.id.spDurationEdit);

        // Get the course ID from intent
        String courseId = getIntent().getStringExtra("COURSE_ID");
        if (courseId == null || courseId.isEmpty()) {
            Toast.makeText(this, "Error: Course not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // Load the course from Firebase
        loadCourse(courseId);
    }

    private void loadCourse(String courseId) {
        dbHelper.getCourse(courseId, new FirebaseDatabaseHelper.DatabaseCallback() {
            @Override
            public void onSuccess(Object result) {
                currentCourse = (YogaCourse) result;
                runOnUiThread(() -> populateForm(currentCourse));
            }

            @Override
            public void onError(Exception e) {
                runOnUiThread(() -> {
                    Toast.makeText(EditYogaCourse.this,
                            "Error loading course: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show();
                    finish();
                });
            }
        });
    }

    private void populateForm(YogaCourse course) {
        // Set spinner selections
        setSpinnerSelection(spDayEdit, course.getDayOfWeek());
        setSpinnerSelection(spTimeEdit, course.getTime());
        setSpinnerSelection(spTypeEdit, course.getType());
        setSpinnerSelection(spDurationEdit, course.getDuration() + " minutes");

        // Set other fields
        ((EditText) findViewById(R.id.edPriceEdit)).setText(String.valueOf(course.getPrice()));
        ((EditText) findViewById(R.id.edCapacityEdit)).setText(String.valueOf(course.getCapacity()));
        ((EditText) findViewById(R.id.edmDesEdit)).setText(course.getDescription());
    }

    private void setSpinnerSelection(Spinner spinner, String value) {
        if (value != null && spinner != null) {
            for (int i = 0; i < spinner.getCount(); i++) {
                if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(value)) {
                    spinner.setSelection(i);
                    break;
                }
            }
        }
    }

    public void onClickEditYogaCourse(View v) {
        // Get references to all input fields
        EditText edPrice = findViewById(R.id.edPriceEdit);
        EditText edCapacity = findViewById(R.id.edCapacityEdit);
        EditText edDescription = findViewById(R.id.edmDesEdit);

        try {
            // Get all updated values from the form
            String dayOfWeek = spDayEdit.getSelectedItem().toString();
            String time = spTimeEdit.getSelectedItem().toString();
            String type = spTypeEdit.getSelectedItem().toString();
            String durationStr = spDurationEdit.getSelectedItem().toString();
            String description = edDescription.getText().toString();

            // Parse numerical values
            int duration = Integer.parseInt(durationStr.replaceAll("[^0-9]", ""));
            int capacity = Integer.parseInt(edCapacity.getText().toString());
            double price = Double.parseDouble(edPrice.getText().toString());

            // Create updated YogaCourse object
            YogaCourse updatedCourse = new YogaCourse(
                    currentCourse.getId(), // Same ID as original
                    dayOfWeek,
                    time,
                    capacity,
                    duration,
                    price,
                    type,
                    description
            );

            // Update in Firebase
            dbHelper.updateCourse(updatedCourse, new FirebaseDatabaseHelper.DatabaseCallback() {
                @Override
                public void onSuccess(Object result) {
                    runOnUiThread(() -> {
                        Toast.makeText(EditYogaCourse.this,
                                "Course updated successfully",
                                Toast.LENGTH_SHORT).show();
                        finish(); // Close the activity
                    });
                }

                @Override
                public void onError(Exception e) {
                    runOnUiThread(() -> {
                        Toast.makeText(EditYogaCourse.this,
                                "Failed to update course: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    });
                }
            });

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numbers for capacity and price", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void onClickClearYogaCourse(View v) {
        // Reset form to original values
        if (currentCourse != null) {
            populateForm(currentCourse);
            Toast.makeText(this, "Changes discarded", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        // No need to close Firebase connection explicitly
        super.onDestroy();
    }
}