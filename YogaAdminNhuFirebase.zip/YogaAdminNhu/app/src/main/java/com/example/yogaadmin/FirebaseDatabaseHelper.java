package com.example.yogaadmin;

import android.content.Context;
import androidx.annotation.NonNull;

import com.example.yogaadmin.course.YogaCourse;
import com.example.yogaadmin.schedule.YogaSchedule;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FirebaseDatabaseHelper {
    private static final String DB_COURSES = "courses";
    private static final String DB_SCHEDULES = "schedules";

    private final DatabaseReference mDatabase;

    public FirebaseDatabaseHelper(Context context) {
        mDatabase = FirebaseDatabase.getInstance().getReference();
    }

    // ==================== YOGA COURSE OPERATIONS ====================

    public void createCourse(YogaCourse course, final DatabaseCallback callback) {
        String key = mDatabase.child(DB_COURSES).push().getKey();
        if (key == null) {
            callback.onError(new Exception("Failed to generate key"));
            return;
        }
        course.setId(key);
        mDatabase.child(DB_COURSES).child(key).setValue(course.toMap())
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onSuccess(key);
                    } else {
                        callback.onError(task.getException());
                    }
                });
    }

    public void getCourse(String id, final DatabaseCallback callback) {
        mDatabase.child(DB_COURSES).child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                YogaCourse course = snapshot.getValue(YogaCourse.class);
                if (course != null) {
                    course.setId(snapshot.getKey());
                    callback.onSuccess(course);
                } else {
                    callback.onError(new Exception("Course not found"));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onError(error.toException());
            }
        });
    }

    public void updateCourse(YogaCourse course, final DatabaseCallback callback) {
        Map<String, Object> updateValues = course.toMap();
        mDatabase.child(DB_COURSES).child(course.getId()).updateChildren(updateValues)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onSuccess(null);
                    } else {
                        callback.onError(task.getException());
                    }
                });
    }

    public void deleteCourse(String id, final DatabaseCallback callback) {
        mDatabase.child(DB_SCHEDULES).orderByChild("courseId").equalTo(id)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot scheduleSnapshot : snapshot.getChildren()) {
                            scheduleSnapshot.getRef().removeValue();
                        }
                        mDatabase.child(DB_COURSES).child(id).removeValue()
                                .addOnCompleteListener(task -> {
                                    if (task.isSuccessful()) {
                                        callback.onSuccess(null);
                                    } else {
                                        callback.onError(task.getException());
                                    }
                                });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        callback.onError(error.toException());
                    }
                });
    }

    public void getAllCourses(final DataLoadCallback<YogaCourse> callback) {
        mDatabase.child(DB_COURSES).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<YogaCourse> courses = new ArrayList<>();
                for (DataSnapshot courseSnapshot : snapshot.getChildren()) {
                    YogaCourse course = courseSnapshot.getValue(YogaCourse.class);
                    if (course != null) {
                        course.setId(courseSnapshot.getKey());
                        courses.add(course);
                    }
                }
                callback.onDataLoaded(courses);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onError(error.toException());
            }
        });
    }

    public void searchCoursesByTeacher(String teacherName, final DataLoadCallback<YogaCourse> callback) {
        mDatabase.child(DB_SCHEDULES).orderByChild("teacher")
                .startAt(teacherName).endAt(teacherName + "\uf8ff")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        List<String> courseIds = new ArrayList<>();
                        for (DataSnapshot scheduleSnapshot : snapshot.getChildren()) {
                            String courseId = scheduleSnapshot.child("courseId").getValue(String.class);
                            if (courseId != null && !courseIds.contains(courseId)) {
                                courseIds.add(courseId);
                            }
                        }
                        fetchCoursesByIds(courseIds, callback);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        callback.onError(error.toException());
                    }
                });
    }

    private void fetchCoursesByIds(List<String> courseIds, final DataLoadCallback<YogaCourse> callback) {
        if (courseIds.isEmpty()) {
            callback.onDataLoaded(new ArrayList<>());
            return;
        }
        mDatabase.child(DB_COURSES).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<YogaCourse> courses = new ArrayList<>();
                for (DataSnapshot courseSnapshot : snapshot.getChildren()) {
                    if (courseIds.contains(courseSnapshot.getKey())) {
                        YogaCourse course = courseSnapshot.getValue(YogaCourse.class);
                        if (course != null) {
                            course.setId(courseSnapshot.getKey());
                            courses.add(course);
                        }
                    }
                }
                callback.onDataLoaded(courses);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onError(error.toException());
            }
        });
    }

    // ==================== SCHEDULE OPERATIONS ====================

    public void createSchedule(YogaSchedule schedule, final DatabaseCallback callback) {
        String key = mDatabase.child(DB_SCHEDULES).push().getKey();
        if (key == null) {
            callback.onError(new Exception("Failed to generate key"));
            return;
        }
        schedule.setId(key);
        mDatabase.child(DB_SCHEDULES).child(key).setValue(schedule.toMap())
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onSuccess(key);
                    } else {
                        callback.onError(task.getException());
                    }
                });
    }

    public void getSchedule(String id, final DatabaseCallback callback) {
        mDatabase.child(DB_SCHEDULES).child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                YogaSchedule schedule = snapshot.getValue(YogaSchedule.class);
                if (schedule != null) {
                    schedule.setId(snapshot.getKey());
                    callback.onSuccess(schedule);
                } else {
                    callback.onError(new Exception("Schedule not found"));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onError(error.toException());
            }
        });
    }

    public void updateSchedule(YogaSchedule schedule, final DatabaseCallback callback) {
        Map<String, Object> updateValues = schedule.toMap();
        mDatabase.child(DB_SCHEDULES).child(schedule.getId()).updateChildren(updateValues)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onSuccess(null);
                    } else {
                        callback.onError(task.getException());
                    }
                });
    }

    public void deleteSchedule(String id, final DatabaseCallback callback) {
        mDatabase.child(DB_SCHEDULES).child(id).removeValue()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        callback.onSuccess(null);
                    } else {
                        callback.onError(task.getException());
                    }
                });
    }

    public void getAllSchedules(final DataLoadCallback<YogaSchedule> callback) {
        mDatabase.child(DB_SCHEDULES).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<YogaSchedule> schedules = new ArrayList<>();
                for (DataSnapshot scheduleSnapshot : snapshot.getChildren()) {
                    YogaSchedule schedule = scheduleSnapshot.getValue(YogaSchedule.class);
                    if (schedule != null) {
                        schedule.setId(scheduleSnapshot.getKey());
                        schedules.add(schedule);
                    }
                }
                callback.onDataLoaded(schedules);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onError(error.toException());
            }
        });
    }

    public void searchSchedulesByTeacher(String teacherName, final DataLoadCallback<YogaSchedule> callback) {
        mDatabase.child(DB_SCHEDULES).orderByChild("teacher")
                .startAt(teacherName).endAt(teacherName + "\uf8ff")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        List<YogaSchedule> schedules = new ArrayList<>();
                        for (DataSnapshot scheduleSnapshot : snapshot.getChildren()) {
                            YogaSchedule schedule = scheduleSnapshot.getValue(YogaSchedule.class);
                            if (schedule != null) {
                                schedule.setId(scheduleSnapshot.getKey());
                                schedules.add(schedule);
                            }
                        }
                        callback.onDataLoaded(schedules);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        callback.onError(error.toException());
                    }
                });
    }

    public void searchCourses(String searchText, final DataLoadCallback<YogaCourse> callback) {
        mDatabase.child(DB_COURSES).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<YogaCourse> courses = new ArrayList<>();
                String searchLower = searchText.toLowerCase();

                for (DataSnapshot courseSnapshot : snapshot.getChildren()) {
                    YogaCourse course = courseSnapshot.getValue(YogaCourse.class);
                    if (course != null) {
                        course.setId(courseSnapshot.getKey());
                        if (course.getDayOfWeek().toLowerCase().contains(searchLower) ||
                                course.getTime().toLowerCase().contains(searchLower) ||
                                course.getType().toLowerCase().contains(searchLower) ||
                                (course.getDescription() != null &&
                                        course.getDescription().toLowerCase().contains(searchLower))) {
                            courses.add(course);
                        }
                    }
                }
                callback.onDataLoaded(courses);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onError(error.toException());
            }
        });
    }

    public void searchSchedulesForCourse(String courseId, String teacherSearch,
                                         final DataLoadCallback<YogaSchedule> callback) {
        mDatabase.child(DB_SCHEDULES).orderByChild("courseId").equalTo(courseId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        List<YogaSchedule> schedules = new ArrayList<>();
                        String teacherLower = teacherSearch != null ? teacherSearch.toLowerCase() : "";

                        for (DataSnapshot scheduleSnapshot : snapshot.getChildren()) {
                            YogaSchedule schedule = scheduleSnapshot.getValue(YogaSchedule.class);
                            if (schedule != null) {
                                schedule.setId(scheduleSnapshot.getKey());
                                if (teacherSearch == null || teacherSearch.isEmpty() ||
                                        schedule.getTeacher().toLowerCase().contains(teacherLower)) {
                                    schedules.add(schedule);
                                }
                            }
                        }
                        callback.onDataLoaded(schedules);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        callback.onError(error.toException());
                    }
                });
    }

    public void searchSchedules(String searchText, String courseId,
                                final DataLoadCallback<YogaSchedule> callback) {
        DatabaseReference ref = (courseId != null && !courseId.isEmpty())
                ? (DatabaseReference) mDatabase.child(DB_SCHEDULES).orderByChild("courseId").equalTo(courseId)
                : mDatabase.child(DB_SCHEDULES);

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<YogaSchedule> schedules = new ArrayList<>();
                String searchLower = searchText.toLowerCase();

                for (DataSnapshot scheduleSnapshot : snapshot.getChildren()) {
                    YogaSchedule schedule = scheduleSnapshot.getValue(YogaSchedule.class);
                    if (schedule != null) {
                        schedule.setId(scheduleSnapshot.getKey());
                        if (schedule.getTeacher().toLowerCase().contains(searchLower) ||
                                schedule.getDate().toLowerCase().contains(searchLower) ||
                                (schedule.getComments() != null &&
                                        schedule.getComments().toLowerCase().contains(searchLower))) {
                            schedules.add(schedule);
                        }
                    }
                }
                callback.onDataLoaded(schedules);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                callback.onError(error.toException());
            }
        });
    }

    public interface DatabaseCallback {
        void onSuccess(Object result);
        void onError(Exception e);
    }

    public interface DataLoadCallback<T> {
        void onDataLoaded(List<T> data);
        void onError(Exception e);
    }
}